# Supply Chain Delay Predictor and Root Cause Dashboard

End-to-end supply chain analysis on Indian logistics data: delay root cause analysis, penalty quantification, Random Forest prediction model, and a 6 panel BI dashboard.

## Business Problem
Procurement teams lose crores annually to supplier delays and contractual penalties. This project identifies which supplier tiers and categories cause the most delays and quantifies the financial impact.

## Key Findings
| Metric | Value |
|---|---|
| Total shipments analysed | 5,000 |
| Overall delay rate | 65.7% |
| Annual penalty exposure | Rs 1.05 crore |
| Tier 3 penalty contribution | Rs 42 lakh |
| Model ROC-AUC | 0.862 |

## How to Run
```bash
pip install -r requirements.txt
python generate_data.py
python supply_chain_analysis.py
```

## Skills Demonstrated
Exploratory data analysis, feature engineering (12 features), Random Forest classification, business intelligence dashboard, stakeholder insight reporting, SQL style aggregations

**Author:** Meghana N | B.E. CSE, Vemana Institute of Technology (2026)
