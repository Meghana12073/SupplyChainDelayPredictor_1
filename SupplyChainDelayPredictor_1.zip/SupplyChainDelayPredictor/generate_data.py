"""
generate_data.py
Generates a realistic Indian supply chain shipment dataset.
Run this first: python generate_data.py
"""
import pandas as pd
import numpy as np
from datetime import datetime, timedelta

np.random.seed(42)
n = 5000

suppliers = {
    "Tier 1": {"reliability": 0.92, "base_delay": 1.5},
    "Tier 2": {"reliability": 0.80, "base_delay": 3.2},
    "Tier 3": {"reliability": 0.61, "base_delay": 6.8},
    "Tier 4": {"reliability": 0.50, "base_delay": 9.1},
}
categories  = ["Electronics", "Textiles", "Auto Parts", "FMCG", "Pharma", "Machinery"]
regions     = ["North", "South", "East", "West"]
start_date  = datetime(2023, 1, 1)

rows = []
for i in range(n):
    tier     = np.random.choice(list(suppliers.keys()), p=[0.25, 0.30, 0.28, 0.17])
    sup      = suppliers[tier]
    cat      = np.random.choice(categories)
    region   = np.random.choice(regions)
    order_dt = start_date + timedelta(days=int(np.random.randint(0, 365)))
    lead_days= int(np.random.randint(3, 30))
    promised = order_dt + timedelta(days=lead_days)

    delay_days = max(0, int(np.random.normal(sup["base_delay"], 2.5)))
    delayed    = 1 if delay_days > 2 else 0

    # penalty in INR: Rs 500 per day of delay per shipment
    penalty_inr = delay_days * 500 if delayed else 0

    order_value_inr = round(np.random.uniform(15000, 950000), 2)
    order_freq      = np.random.randint(1, 25)

    rows.append({
        "shipment_id":      f"SHP{i+1:05d}",
        "order_date":       order_dt.strftime("%Y-%m-%d"),
        "promised_date":    promised.strftime("%Y-%m-%d"),
        "supplier_tier":    tier,
        "category":         cat,
        "region":           region,
        "lead_time_days":   lead_days,
        "delay_days":       delay_days,
        "delayed":          delayed,
        "order_value_inr":  order_value_inr,
        "order_frequency":  order_freq,
        "penalty_inr":      penalty_inr,
    })

df = pd.DataFrame(rows)
df.to_csv("data/shipments.csv", index=False)
total_penalty = df["penalty_inr"].sum()
print(f"Dataset saved: {len(df)} rows")
print(f"Delayed shipments: {df['delayed'].sum()} ({df['delayed'].mean()*100:.1f}%)")
print(f"Total penalties: Rs {total_penalty:,.0f}")
